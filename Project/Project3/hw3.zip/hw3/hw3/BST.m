//
//  BST.m
//  hw3
//
//  Created by Feng, Zihang on 4/7/14.
//  Copyright (c) 2014 UIC. All rights reserved.
//

#import "BST.h"

@implementation BST
@synthesize root;

-(void) clear:(BST*) tree
{
    if(tree->root != NULL)
        tree->root = NULL;
}

-(void) switchSet:(BST*) tree1 othertree:(BST*) tree2
{
    BST* temp = [[BST alloc] init];
    temp = tree1;
    tree1 = tree2;
    tree2 = tree1;
}



-(NSString*) display:(NODE*) root{
    if([self root] != NULL)
    {
        NSString* theList = [NSString stringWithFormat:@"%i", [[self root] val]];
        [self display:[[self root] left]];
        [self display:[[self root] right]];
        return theList;
    }
    return NULL;
}

-(void) add:(NODE*) root content:(int)value{
    NODE* temp = [[NODE alloc] init];
    [temp setLeft:NULL];
    [temp setRight:NULL];
    [temp setVal: value];
    
    NODE *curr, *prev;
    
    curr = [self root];
    prev = NULL;
    while(curr != NULL){
        prev = curr;
        if([curr val] > value){
            curr = [curr left];
        }
        else{
            curr = [curr right];
        }
    }
    
    if(prev == NULL){
        [self setRoot:temp];
    }
    else{
        if([prev val] > value){
            [prev setLeft: temp];
        }
        else{
            [prev setRight: temp];
        }
    }
}

-(void) save:(NODE*) root1 otherRoot:(NODE*) root2{
    if(root1 != NULL)
    {
        root2= [[NODE alloc] init];
        [self add: root1 content: [root2 val]];
        if ([root1 left] != NULL) {
            [self save: [root1 left] otherRoot: [root2 left]];
        }
        
        if([root1 right] != NULL){
            [self save: [root1 right] otherRoot: [root2 right]];
        }
    }
}

-(bool) contain:(NODE*) root content:(int) value{
    bool determination;
    if([self root] != NULL){
        if([[self root] val] != value){
            if([[self root] val] > value){
                determination = [self contain: [[self root] left] content: value];
                return determination;
            }
            else{
                determination = [self contain: [[self root] right] content: value];
                return determination;
            }
        }
        else{
            return true;
        }
    }
    return false;
}

-(void) unionSet:(NODE*) root1 otherRoot:(NODE*) root2{
    if(root2 != NULL){
        if(![self contain: root1 content: [root2 val]])
        {
            [self add: root1 content: [root2 val]];
        }
        
        [self unionSet: root1 otherRoot: [root2 left]];
        [self unionSet: root1 otherRoot: [root2 right]];
    }
}


@end
