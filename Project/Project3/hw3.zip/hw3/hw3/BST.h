//
//  BST.h
//  hw3
//
//  Created by Feng, Zihang on 4/7/14.
//  Copyright (c) 2014 UIC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NODE.h"
@interface BST : NSObject{
    NODE *root;
}
@property (nonatomic, strong) NODE* root;

-(void) clear:(BST*) tree;
-(void) switchSet:(BST*) tree1 othertree:(BST*) tree2;
-(void) add:(NODE*) root content:(int)value;
-(void) save:(NODE*) root1 otherRoot:(NODE*) root2;
-(NSString*) display:(NODE*) tree;
-(bool) contain:(NODE*) root content:(int) value;
-(void) unionSet:(NODE*) root1 otherRoot:(NODE*) root2;
@end
