//
//  ViewController.m
//  hw3
//
//  Created by Feng, Zihang on 4/6/14.
//  Copyright (c) 2014 UIC. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *output1;
@property (weak, nonatomic) IBOutlet UITextField *output2;

@property (weak, nonatomic) IBOutlet UITextField *input;
@end

static BST *tree1, *tree2;
NSString *list1, *list2;

@implementation ViewController

- (IBAction)Clear_set:(id)sender {
    [self.output1 setText:NULL];
    list1 = NULL;
    [tree1 clear:tree1];
    [tree2 clear:tree2];
}

- (IBAction)addElement:(id)sender {
    int value = [[[self input] text] integerValue];
    [tree1 add: [tree1 root] content: value];
    
}

- (IBAction)saveList:(id)sender {
    tree2 = [[BST alloc] init];
    [tree1 save: [tree1 root] otherRoot: [tree2 root]];
}

- (IBAction)switchSet:(id)sender {
    [tree1 switchSet:tree1 othertree:tree2];
}

- (IBAction)displaySet:(id)sender {
    list1 = [tree1 display:[tree1 root]];
    [self.output1 setText:list1];
}
- (IBAction)unionSet:(id)sender {
    [tree1 unionSet:[tree1 root] otherRoot:[tree2 root]];
}
- (IBAction)declare:(id)sender {
    tree1 = [[BST alloc] init];
    tree2 = [[BST alloc] init];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
